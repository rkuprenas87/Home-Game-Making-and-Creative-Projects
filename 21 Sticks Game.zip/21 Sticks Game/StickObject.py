class Stick:
    objects = []

    def __init__(self,name, image = "|"):
        self.name = name
        self.image = image
        Stick.objects.append(self)


    def __repr__(self):
        return f"{self.name} ({self.image})"

def PrintSticks():
    print(" ".join(stick.image for stick in Stick.objects))

def PrintTotalNumberOfSticks():
    print("Sticks Remaining: ", len(Stick.objects))
