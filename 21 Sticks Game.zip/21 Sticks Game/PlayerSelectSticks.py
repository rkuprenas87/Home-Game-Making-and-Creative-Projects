from StickObject import Stick, PrintSticks, PrintTotalNumberOfSticks
import GameState

def PlayerSelectSticks():
    # Helper to label current player without changing the turn
    def currentPlayerName():
        return "Player 1" if GameState.player1Turn else "Player 2"

    # Normal turn while 3 or more sticks remain
    while len(Stick.objects) >= 3:
        playerSelection = input("Select 1, 2, or 3 sticks to remove: ")
        # Remember which player made THIS move
        mover = currentPlayerName()

        if playerSelection == "1":
            Stick.objects.pop()
            print(f"{mover} removed 1 stick\n")
        elif playerSelection == "2":
            Stick.objects.pop()
            Stick.objects.pop()
            print(f"{mover} removed 2 sticks\n")
        elif playerSelection == "3":
            Stick.objects.pop()
            Stick.objects.pop()
            Stick.objects.pop()
            print(f"{mover} removed 3 sticks\n")
        else:
            print("Please enter 1, 2, or 3.")
            continue  # re-prompt without toggling turn

        # Toggle turn AFTER a valid move
        GameState.player1Turn = not GameState.player1Turn

        # If 2 or fewer remain, show the board before final prompt
        if len(Stick.objects) <= 2:
            PrintTotalNumberOfSticks()
            PrintSticks()
        break  # exit to handle final states below

    # Final states (2 or 1 sticks left)
    if len(Stick.objects) == 2:
        # Ask the player whose turn it is now
        playerSelection = input("Select 1 or 2 sticks to remove: ")
        mover = currentPlayerName()

        if playerSelection == "1":
            # mover takes 1 -> 1 remains -> other player must take last -> mover WINS
            Stick.objects.pop()
            print(f"{mover} removed 1 stick")
            print("Game Over!")
            print(f"{mover} Wins!")
            Stick.objects.clear()
        elif playerSelection == "2":
            # mover takes last 2 -> mover loses (whoever takes last stick loses)
            Stick.objects.pop(); Stick.objects.pop()
            print(f"{mover} removed 2 sticks")
            print("Game Over!")
            loser = mover
            winner = "Player 2" if loser == "Player 1" else "Player 1"
            print(f"{winner} Wins!")
            Stick.objects.clear()
        else:
            print("Please enter 1 or 2.")

    elif len(Stick.objects) == 1:
        # If we ever land here (rare with the above flow), the player who left 1 just moved.
        # Current player must take the last stick and lose, so previous mover wins.
        print("Game Over!")
        winner = "Player 2" if GameState.player1Turn else "Player 1"
        print(f"{winner} Wins!")
        Stick.objects.clear()

    # If the game ended (0 or 1), prompt for replay and reset turn
    if len(Stick.objects) <= 1:
        input("Press Enter to play again")
        import StartGame
        GameState.player1Turn = True
        StartGame.StartGame()






# from StickObject import Stick
# from StartGame import StartGame
# import GameState
#
# def PlayerSelectSticks():
#     global player1Turn
#     while len(Stick.objects) >= 3:
#         playerSelection = input("Select 1, 2, or 3 sticks to remove: ")
#         if playerSelection == "1":
#             Stick.objects.pop()
#             print("Player removed 1 stick\n")
#             GameState.player1Turn = not GameState.player1Turn
#         elif playerSelection == "2":
#             Stick.objects.pop()
#             Stick.objects.pop()
#             print("Player removed 2 sticks\n")
#             GameState.player1Turn = not GameState.player1Turn
#         elif playerSelection == "3":
#             Stick.objects.pop()
#             Stick.objects.pop()
#             Stick.objects.pop()
#             print("Player removed 3 sticks\n")
#             GameState.player1Turn = not GameState.player1Turn
#         break
#     if len(Stick.objects) == 2:
#         playerSelection = input("Select 1 or 2 sticks to remove: ")
#         if playerSelection == "1":
#             print("Game Over!")
#             winner = "Player 2" if GameState.player1Turn else "Player 1"
#             print(f"{winner} Wins!")
#             Stick.objects.clear()
#         elif playerSelection == "2":
#             print("Game Over!")
#             winner = "Player 1" if (not GameState.player1Turn) else "Player 2"
#             print(f"{winner} Wins!")
#             Stick.objects.clear()
#     elif len(Stick.objects) == 1:
#         print("Game Over!")
#         winner = "Player 2" if GameState.player1Turn else "Player 1"
#         print(f"{winner} Wins!")
#         Stick.objects.clear()
#
#     if len(Stick.objects) == 0 or len(Stick.objects) == 1:
#         input("Press any key to play again")
#         import StartGame
#         GameState.player1Turn = True
#         StartGame.StartGame()
