from StickObject import PrintSticks, PrintTotalNumberOfSticks, Stick
from StartGame import StartGame
from AddSticks import AddSticks
from RemoveSticks import RemoveStick
from PlayerSelectSticks import PlayerSelectSticks
from DisplayDirections import DisplayDirections
from PrintPlayerTurn import PrintPlayerTurn



DisplayDirections()
StartGame()
while len(Stick.objects) > 1:
    PrintTotalNumberOfSticks()
    PrintSticks()
    PrintPlayerTurn()
    PlayerSelectSticks()
