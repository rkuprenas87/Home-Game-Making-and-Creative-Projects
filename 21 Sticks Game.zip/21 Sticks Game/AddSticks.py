from StickObject import Stick

def AddSticks(name, image="|"):
    new_stick = Stick(name, image)
    print(f"Added: {new_stick}")
