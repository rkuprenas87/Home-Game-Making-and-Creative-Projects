def DisplayDirections():
    print("21 Sticks Game\n")
    print("Take turns removing 1, 2, or 3 sticks at a time.")
    print("Whoever takes the last stick loses.")
    print("Can you find a strategy to win consistently?\n")