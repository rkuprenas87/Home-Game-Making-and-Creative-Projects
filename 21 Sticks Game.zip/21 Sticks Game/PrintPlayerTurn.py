import GameState

def PrintPlayerTurn():
    which = "Player 1" if GameState.player1Turn else "Player 2"
    print(f"{which} turn")
