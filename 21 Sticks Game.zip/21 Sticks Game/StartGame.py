from StickObject import Stick

def StartGame():
    global player1Turn
    Stick.objects.clear()
    for i in range(1, 22):
        stick = Stick(f"Stick {i}", "|")
    player1Turn = True