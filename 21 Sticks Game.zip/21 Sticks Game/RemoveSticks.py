from StickObject import Stick

def RemoveStick(name):
    for stick in Stick.objects:
        if stick.name == name:
            Stick.objects.remove(stick)
            print(f"Removed: {name}")
            return
    print(f"No stick found with name: {name}")

