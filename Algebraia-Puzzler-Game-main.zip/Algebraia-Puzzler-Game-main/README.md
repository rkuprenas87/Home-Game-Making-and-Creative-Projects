This just includes a tutorial for a math RPG game. If you complete the tutorial, you can 
explore a world map with many different screens, but there aren't any objects to interact with.
The storyline has some small humor built in.

Known Bugs:
The ruler and protractor weapons do not work with the inventory, so just use the mathology bolts for battling.
If you try really hard, you can get yourself stuck in a doorway, and you will have to restart.
Some menus work better than others.

All art, sound effects, and story was self-made.
